import React from 'react';
import { motion } from 'motion/react';
import { ArrowLeftRight, ArrowRight } from 'lucide-react';

const books = [
  {
    title: "O Paradoxo do Amor",
    subtitle: "Necessidade vs Capacidade",
    desc: "Uma investigação psicanalítica sobre o amor, suas contradições e os impasses entre a carência afetiva e a construção de vínculos maduros.",
    image: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=600",
    linkText: "VER LIVRO"
  },
  {
    title: "A Clínica da Invenção",
    subtitle: "Casos de Sucesso no Tratamento Psicanalítico do Autismo no Brasil e no Mundo",
    desc: "Uma obra que apresenta a clínica psicanalítica do autismo a partir de casos reais, evidenciando a potência da invenção subjetiva frente aos impasses do diagnóstico contemporâneo.",
    image: "https://images.unsplash.com/photo-1541963463532-d68292c34b19?auto=format&fit=crop&q=80&w=600",
    linkText: "SAIBA MAIS"
  },
  {
    title: "Entre o Desejo e o Medo",
    subtitle: "A ansiedade sob o olhar da psicanálise",
    desc: "Uma leitura acessível e profunda sobre a ansiedade, articulando Freud, Lacan e a clínica contemporânea.",
    image: "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&q=80&w=600",
    linkText: "ACESSAR CONTEÚDO"
  }
];

export default function FeaturedBooks() {
  return (
    <section id="publicacoes" className="bg-[#0D0D0D] py-32">
      <div className="section-container">
        <div className="flex justify-between items-end mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xs tracking-[0.4em] uppercase text-gray-500 mb-4">LIVROS EM DESTAQUE</h3>
            <div className="w-12 h-[1px] bg-gold" />
          </motion.div>
          
          <a href="#" className="text-xs tracking-widest text-gray-400 hover:text-gold transition-colors flex items-center gap-2">
            VER TODOS OS LIVROS <ArrowRight className="w-3 h-3" />
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 lg:gap-20">
          {books.map((book, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: idx * 0.2 }}
              viewport={{ once: true }}
              className="flex flex-col items-center text-center group"
            >
              <div className="relative mb-8 w-full max-w-[280px] aspect-[2/3] overflow-hidden shadow-2xl transition-transform duration-500 group-hover:scale-105">
                <img 
                  src={book.image} 
                  alt={book.title} 
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center p-6 pb-12">
                   {/* Overlay content if needed */}
                </div>
              </div>
              
              <h4 className="text-xl mb-2 font-serif text-white">{book.title}</h4>
              <p className="text-[10px] tracking-wider uppercase text-gold mb-4 opacity-80">{book.subtitle}</p>
              <p className="text-xs text-gray-500 font-light leading-relaxed mb-8 line-clamp-3">
                {book.desc}
              </p>
              
              <a href="#" className="btn-outline text-[10px] tracking-widest py-2 px-6 group">
                {book.linkText}
                <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
