import React from 'react';
import { motion } from 'motion/react';
import { Brain, Users, Book, GraduationCap, Presentation, PencilLine, ArrowRight } from 'lucide-react';

const areas = [
  { icon: Brain, title: "Psicanálise Clínica" },
  { icon: Book, title: "Filosofia e Psicanálise" },
  { icon: Users, title: "Saúde Mental" },
  { icon: GraduationCap, title: "Docência e Formação Acadêmica" },
  { icon: Presentation, title: "Palestras e Seminários" },
];

export default function AboutAndAreas() {
  return (
    <section id="sobre" className="bg-dark-bg py-32 overflow-hidden">
      <div className="section-container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24">
          {/* About Me */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xs tracking-[0.4em] uppercase text-gray-500 mb-8 flex items-center gap-4">
              <span className="w-8 h-[1px] bg-gold" /> SOBRE
            </h3>
            
            <h2 className="text-3xl font-serif mb-8 text-white italic">Lúcio Escobar</h2>

            <div className="space-y-6 text-gray-400 font-light leading-relaxed text-justify">
              <p>
                Lúcio Escobar é psicanalista clínico, professor, escritor e poeta, com atuação consolidada na interseção entre psicanálise, filosofia e saúde mental. Atualmente é doutorando em Psicanálise pela Logos University International (EUA), sob orientação do Dr. Gabriel Lopes.
              </p>
              <p>
                Possui trajetória acadêmica interdisciplinar, com formação em filosofia, teologia, antropologia e psicanálise clínica, o que sustenta uma prática teórica e clínica voltada à escuta do sujeito em sua singularidade. Atua também como orientador e professor colaborador na Logos University International, além de ser membro da American Philosophical Association e da Associação Brasileira de Psicanálise.
              </p>
              <p>
                Sua produção articula psicanálise com temas contemporâneos como ansiedade, suicídio, corpo, religião, autismo e cultura digital, consolidando uma abordagem crítica e ética frente aos discursos hegemônicos sobre saúde mental.
              </p>
            </div>
          </motion.div>

          {/* Acting Areas */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xs tracking-[0.4em] uppercase text-gray-500 mb-12 flex items-center gap-4">
              <span className="w-8 h-[1px] bg-gold" /> ÁREAS DE ATUAÇÃO
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-y-12 gap-x-8">
              {areas.map((area, idx) => (
                <div key={idx} className="flex flex-col group border-l border-white/5 pl-6 hover:border-gold transition-colors">
                  <div className="w-10 h-10 flex items-center mb-4 transition-transform group-hover:-translate-y-1">
                    <area.icon className="w-6 h-6 text-gold opacity-80" strokeWidth={1.5} />
                  </div>
                  <span className="text-[12px] tracking-widest uppercase text-gray-300 font-medium mb-2">
                    {area.title}
                  </span>
                  <p className="text-[10px] text-gray-500 leading-relaxed uppercase tracking-tighter">
                    Prática teórica e clínica voltada à singularidade do sujeito.
                  </p>
                </div>
              ))}
            </div>
            
            <p className="mt-12 text-xs text-gray-500 italic border-t border-white/5 pt-8">
              "Atua especialmente na interface entre clínica psicanalítica e questões contemporâneas, com ênfase na subjetividade e no sofrimento psíquico."
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
